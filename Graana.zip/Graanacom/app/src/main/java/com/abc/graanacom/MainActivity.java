package com.abc.graanacom;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.util.Base64Utils;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "";
    LinearLayout layout;
    SearchView keyword;
    Button search;
    TextView acc, car, disp, cylinder, horsepower, mgp, model, origin, weight, sorry;
    String carr, accr, mod, cylin, hp, mgpp, orig, dis, weig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = findViewById(R.id.layout);
        keyword = findViewById(R.id.keyword);
        search = findViewById(R.id.search);
        acc = findViewById(R.id.acc);
        car = findViewById(R.id.car);
        disp = findViewById(R.id.disp);
        cylinder = findViewById(R.id.cylinders);
        horsepower = findViewById(R.id.horse);
        mgp = findViewById(R.id.mgp);
        model = findViewById(R.id.model);
        origin = findViewById(R.id.origin);
        weight = findViewById(R.id.weight);
        sorry = findViewById(R.id.sorry);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout.setVisibility(View.VISIBLE);
                final String key = String.valueOf(keyword.getQuery());
                Toast.makeText(MainActivity.this, key, Toast.LENGTH_SHORT).show();

                if (!key.equals("")){
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                    final boolean[] test = {true};
                for(int i = 0; i<=406 && test[0]; i++){
                    Log.d("forr loop", String.valueOf(i));
                    DatabaseReference myRef = database.getReference().child(String.valueOf(i));
                    // Read from the database
                    myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            Log.d("data", "dataSnapshot");
                            carr = dataSnapshot.child("Car").getValue(String.class);
                            accr = dataSnapshot.child("Acceleration").getValue(String.class);
                            mod = dataSnapshot.child("Model").getValue(String.class);
                            cylin = dataSnapshot.child("Cylinders").getValue(String.class);
                            hp = dataSnapshot.child("Horsepower").getValue(String.class);
                            mgpp = dataSnapshot.child("MPG").getValue(String.class);
                            orig = dataSnapshot.child("Origin").getValue(String.class);
                            dis = dataSnapshot.child("Displacement").getValue(String.class);
                            weig = dataSnapshot.child("Weight").getValue(String.class);
                            Log.d("Value", "Value is: " + carr);
                            if (key.equalsIgnoreCase(carr)){
                                car.setText(carr);
                                acc.setText(accr);
                                model.setText(mod);
                                cylinder.setText(cylin);
                                horsepower.setText(hp);
                                mgp.setText(mgpp);
                                origin.setText(orig);
                                disp.setText(dis);
                                weight.setText(weig);
                                sorry.setVisibility(View.INVISIBLE);
                                layout.setVisibility(View.VISIBLE);
                                test[0] = false;
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError error) {
                            // Failed to read value
                            Log.w(TAG, "Failed to read value.", error.toException());
                        }
                    });
                }
                    if (test[0]) {
                        layout.setVisibility(View.INVISIBLE);
                        sorry.setVisibility(View.VISIBLE);
                    }


                }else {
                    sorry.setVisibility(View.VISIBLE);
                    layout.setVisibility(View.INVISIBLE);
                }
            }
        });
    }

}